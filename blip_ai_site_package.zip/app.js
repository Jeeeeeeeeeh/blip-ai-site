import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";

export default function BlipAiLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white p-4">
      <header className="text-center py-8">
        <h1 className="text-4xl font-bold tracking-tight">BLIP AI Coin</h1>
        <p className="text-xl mt-2">Trust the AI? Trust the Hype?</p>
        <Button className="mt-4">Buy $BLIPA</Button>
      </header>

      <section className="max-w-3xl mx-auto grid gap-6 py-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="bg-slate-800">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-2">What is BLIP AI?</h2>
              <p className="mb-4">
                A meme token born from the absurdity of AI-driven trust scores. $BLIPA mocks the rise of algorithm-based social credibility. It's just a blip — or is it?
              </p>
              <Image
                src="/blip-ai-image.png"
                alt="BLIP AI Illustration"
                width={600}
                height={400}
                className="rounded-xl mx-auto mt-4"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <Card className="bg-slate-800">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-2">Tokenomics</h2>
              <ul className="list-disc list-inside">
                <li>Total Supply: 1,000,000,000 $BLIPA</li>
                <li>Liquidity: 50%</li>
                <li>Community Rewards: 25%</li>
                <li>Team: 15%</li>
                <li>Marketing: 10%</li>
              </ul>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <Card className="bg-slate-800">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-2">Roadmap</h2>
              <ol className="list-decimal list-inside space-y-1">
                <li>Q2 2025 – Meme launch & community airdrop</li>
                <li>Q3 2025 – Listing on DEX</li>
                <li>Q4 2025 – AI Trust Game launch</li>
                <li>2026 – Expansion to other social platforms</li>
              </ol>
            </CardContent>
          </Card>
        </motion.div>
      </section>

      <footer className="text-center text-sm text-gray-400 py-6">
        © 2025 BLIP AI. All rights reserved.
      </footer>
    </div>
  );
}
